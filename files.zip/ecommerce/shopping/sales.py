# from ecommerce.customer import contact
# from ..customer import contact   


# contact.contact_customer

# print("SALES INITIALIZED", __name__)        # This shows as __main__ in OUTPUT if runned from sales.py.
def calc_shipping(self):
    pass

def calc_tax(self):
    pass

if __name__ == "__main__":                   # This can use as a script as well as a reusable module that we can import into another module.
    print("Sales Started")
    calc_tax()
