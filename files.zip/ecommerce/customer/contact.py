from re import L


def contact_customer(self):
    pass